En el script Practica5.cs hay 4 campos serializables.

Esto son texturas y corresponden a las texturas del menú,
las opciones para modificar las imágenes de las tarjetas.

Si no se pone ninguna textura no cambiará.

Es muy posible que las imágenes default puestas por el editor no se encuentren
porque las rutas sean diferentes, sería necesario asignarlas uno mismo en el
editor de UIToolkit.